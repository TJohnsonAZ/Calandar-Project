package com.example.calandarapp;

import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class Notes extends AppCompatActivity {

    EditText dailyNote;

    /*
    public void Save(String fileName) {
        try {
            OutputStreamWriter out =
                    new OutputStreamWriter(openFileOutput(fileName, 0));
            out.write(dailyNote.);
            out.close();
            Toast.makeText(this, "Note Saved!", Toast.LENGTH_SHORT).show();
        } catch (Throwable t) {
            Toast.makeText(this, "Exception: " + t.toString(), Toast.LENGTH_LONG).show();
        }
    }
     */
}
